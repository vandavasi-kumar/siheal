import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const HealthForm = () => {
  const [showLogo, setShowLogo] = useState(true);
  const [qrScanned, setQrScanned] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    dob: '',
    location: '',
    healthConditions: [],
  });

  const [locationGranted, setLocationGranted] = useState(false);
  const [showLocationPrompt, setShowLocationPrompt] = useState(false);
  const [locationMessage, setLocationMessage] = useState('');

  const [availableConditions, setAvailableConditions] = useState([
    'Asthma',
    'Pneumonia',
    'Heart Disease',
    'Diabetes',
    'Arthritis',
    'COPD'
  ]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowLogo(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  const requestLocationAccess = () => {
    setShowLocationPrompt(true);
  };

  const handleLocationPermission = (granted) => {
    setShowLocationPrompt(false);
    if (granted) {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          position => {
            const loc = `${position.coords.latitude},${position.coords.longitude}`;            
            setFormData(prev => ({ ...prev, location: loc }));
            setLocationGranted(true);
            setLocationMessage('Thank you! We will act as your AI physician.');
          },
          error => {
            console.error('Location access error:', error);
            setLocationMessage('Unable to retrieve location.');
          }
        );
      }
    } else {
      setLocationMessage('I am sorry but we need your location access to predict your health conditions.');
    }
  };

  const handleChange = e => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleConditionChange = e => {
    const options = e.target.options;
    const selected = [];
    for (let i = 0; i < options.length; i++) {
      if (options[i].selected) {
        selected.push(options[i].value);
      }
    }
    setFormData(prev => ({ ...prev, healthConditions: selected }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Submitting:', formData);
  
    fetch('https://4596-34-80-185-200.ngrok-free.app/', {  // <-- Replace this with your Flask API URL
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(formData)
    })
      .then(response => {
        if (response.ok) {
          alert('Form submitted successfully!');
        } else {
          alert('Something went wrong. Please try again.');
        }
      })
      .catch(error => {
        console.error('API Error:', error);
        alert('Failed to connect to the server.');
      });
  };

  if (showLogo) {
    return (
      <div style={{
        backgroundColor: '#f9c041',
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center'
      }}>
        <img
          src="https://media.licdn.com/dms/image/v2/C560BAQGQKgx9MLq0Hw/company-logo_200_200/company-logo_200_200/0/1630650303843/sreenivasa_inst_of_technology__management_studies_thimmasamudram_chittoor_logo?e=2147483647&v=beta&t=ntj5AcfdUCbxcgASiYoMMTAzfYfs320Tsvg2FqzYAtc"
          alt="Logo"
          style={{ width: '150px', borderRadius: '50%', animation: 'fadeIn 2s' }}
        />
        <h1 style={{ fontWeight: 'bold', marginTop: '1rem' }}>SiHeal</h1>
        <p>powered by Vydehi Hospitals</p>
      </div>
    );
  }

  if (!qrScanned) {
    return (
      <div style={{
        backgroundColor: '#ffd372',
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: 'Calibri'
      }}>
        <h2 style={{ fontWeight: 'bold' }}>Pair with your Smart Watch</h2>
        <p>Scan this QR code from your watch to continue</p>
        <img src="https://api.qrserver.com/v1/create-qr-code/?data=SiHeal-Watch-Pairing" alt="QR Code" />
        <button onClick={() => setQrScanned(true)} className="btn btn-dark mt-3">I have scanned</button>
      </div>
    );
  }

  return (
    <div style={{
      backgroundImage: 'url(https://assets.teenvogue.com/photos/611d10d570d7b312d760d60f/master/w_775%2Cc_limit/GettyImages-1125680650.jpg)',
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      minHeight: '100vh',
      fontFamily: 'Calibri',
      padding: '2rem'
    }}>
      <div className="container bg-light p-4 rounded">
        <div className="text-center mb-4">
          <img
            src="https://media.licdn.com/dms/image/v2/C560BAQGQKgx9MLq0Hw/company-logo_200_200/company-logo_200_200/0/1630650303843/sreenivasa_inst_of_technology__management_studies_thimmasamudram_chittoor_logo?e=2147483647&v=beta&t=ntj5AcfdUCbxcgASiYoMMTAzfYfs320Tsvg2FqzYAtc"
            alt="Logo"
            style={{ width: '100px', borderRadius: '50%', display: 'block', margin: '0 auto' }}
          />
          <h2 className="mt-2" style={{ fontWeight: 'bold' }}>Help Us Understand You Better!</h2>
        </div>
        <form onSubmit={handleSubmit} autoComplete="on">
          <div className="mb-3">
            <label htmlFor="name" className="form-label" style={{ fontWeight: 'bold', fontSize: '16px', color: 'black' }}>Name</label>
            <input
              type="text"
              className="form-control"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              style={{ fontSize: '12px' }}
            />
          </div>

          <div className="mb-3">
            <label htmlFor="dob" className="form-label" style={{ fontWeight: 'bold', fontSize: '16px', color: 'black' }}>Date of Birth</label>
            <input
              type="date"
              className="form-control"
              id="dob"
              name="dob"
              value={formData.dob}
              onChange={handleChange}
              required
              style={{ fontSize: '12px' }}
            />
          </div>

          <div className="mb-3">
            <label className="form-label" style={{ fontWeight: 'bold', fontSize: '16px', color: 'black' }}>Location Access</label>
            <input
              type="text"
              className="form-control"
              value={locationGranted ? formData.location : 'Click here to provide location'}
              readOnly
              required
              style={{ fontSize: '12px', cursor: 'pointer' }}
              onClick={requestLocationAccess}
            />
            {showLocationPrompt && (
              <div className="mt-2">
                <p>Allow location access?</p>
                <button className="btn btn-success me-2" onClick={() => handleLocationPermission(true)}>Yes</button>
                <button className="btn btn-danger" onClick={() => handleLocationPermission(false)}>No</button>
              </div>
            )}
            {locationMessage && (
              <div className="mt-2 alert alert-info">{locationMessage}</div>
            )}
          </div>

          <div className="mb-3">
            <label htmlFor="healthConditions" className="form-label" style={{ fontWeight: 'bold', fontSize: '16px', color: 'black' }}>Health Conditions</label>
            <select
              multiple
              className="form-control"
              id="healthConditions"
              name="healthConditions"
              onChange={handleConditionChange}
              value={formData.healthConditions}
              required
              style={{ fontSize: '12px' }}
            >
              {availableConditions.map((condition, index) => (
                <option key={index} value={condition}>{condition}</option>
              ))}
            </select>
            <small className="form-text text-muted">Hold Ctrl (Cmd on Mac) to select multiple</small>
          </div>

          <button type="submit" className="btn btn-primary">Submit</button>
        </form>
      </div>
    </div>
  );
};

export default HealthForm;