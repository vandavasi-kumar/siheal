import React from "react";
import './style.css';
import App from "./App.jsx";
import 'bootstrap/dist/css/bootstrap.min.css';
import "bootstrap/dist/js/bootstrap.min.js";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import HealthForm from "./App.jsx";

createRoot(document.getElementById("root")).render(
    <StrictMode>
      <HealthForm />
    </StrictMode>
);
